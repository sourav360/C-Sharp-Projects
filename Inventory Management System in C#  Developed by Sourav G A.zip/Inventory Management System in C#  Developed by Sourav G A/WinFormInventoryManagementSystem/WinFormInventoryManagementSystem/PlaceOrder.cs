﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormInventoryManagementSystem
{

    public partial class PlaceOrder : Form
    {

        private DataAccess Da { get; set; }

        private DataSet Ds { get; set; }

        private string Sql { get; set; }

        private Form1 Flogin { get; set; }

        private ImsDashboard MsDashboard { get; set; }




        public PlaceOrder()
        {
            InitializeComponent();
            this.Da = new DataAccess();

            this.AutoGenerateSaleID();
            
        }

        public PlaceOrder(string info, ImsDashboard msDashboard)
        {
            InitializeComponent();
            this.MsDashboard = msDashboard;

            this.Da = new DataAccess();

            this.lblSalesmanId.Text = info;
            this.AutoGenerateSaleID();

        }







  




        private ManagerDashboard AManagerDashboard { get; set; }

        public PlaceOrder(string infoMd,ManagerDashboard amanagerDashboard)
            : this()
        {
            InitializeComponent();
            this.AManagerDashboard = amanagerDashboard;
            this.lblSalesmanId.Text = infoMd;
        }




         


        private void PlaceOrder_FormClosed(object sender, FormClosedEventArgs e)
        {
                
           Application.Exit();
        }

        private void btnToDashboard_Click(object sender, EventArgs e)
        {
            this.lblUpdate.Text = this.lblSalesmanId.Text;
            try
            {
                if (this.lblSalesmanId.Text == "m-101")
                {
                    this.Hide();
                    this.AManagerDashboard.Show();
                }
                else
                {
                    this.Hide();
                    this.MsDashboard.Show();
                }

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured \n\n" + exc.Message);
            }

        }






        private void PopulateGridViewSale()
        {
            string sql = "select * from ordersale;";
            this.Ds = this.Da.ExecuteQuery(sql);



            this.dvgSale.AutoGenerateColumns = false;
            this.dvgSale.DataSource = this.Ds.Tables[0];
        }

        private void btnShowdetailSale_Click(object sender, EventArgs e)
        {
            try
            {


                string sql = "select * from ordersale;";
                this.Ds = this.Da.ExecuteQuery(sql);



                this.dvgSale.AutoGenerateColumns = false;
                this.dvgSale.DataSource = this.Ds.Tables[0];
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured \n\n" + exc.Message);
            }

        }



        private void AutoGenerateSaleID()
        {
            try
            {

                this.Sql = "select * from ordersale order by sid desc ";
                DataTable dt = this.Da.ExecuteQueryTable(this.Sql);
                string id = dt.Rows[0]["sid"].ToString();
                string[] str = id.Split('-');
                int number = Convert.ToInt32(str[1]);
                string autoId = "s-" + (++number).ToString("d3");

                this.txtsId.Text = autoId;
            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }


        }


        private void AddtoCartNew()
        {

         

            try
            {

        
                    this.Sql = @"insert into ordersale
                    values ('" + this.txtsId.Text + "', '" + this.nudLaptopPo.Text + "','" + this.nudDesktopPo.Text + "','" + this.nudPrinterPo.Text + "', '" + this.nudPendrivePo.Text + "',' " + this.txtPricePo.Text + "', '" + this.dtpInsertdatePo.Text + "', '" + this.txtTotalPo.Text + "', '" + this.lblSalesmanId.Text + "', '" + this.nudDiscount.Text + "');";

                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Product Add to Cart in IMS ");
                        //this.GenerateProductID();
                    }
                    else
                    {
                        MessageBox.Show("Data insertion Add to Cart failed");
                    }
          


                //this.PopulateGridView();
                //this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during saving the data\n\n" + exc.Message);
            }


        }

        private void btnAddtoCart_Click(object sender, EventArgs e)
        {
            this.AddtoCartNew();


            try
            {

                this.csid.Text = this.txtsId.Text;
                this.nudOutLaptopPo.Value = this.nudLaptopPo.Value;

                /*    int valueOne = int.Parse(txtQuantity.Text);
                    int valuetwo = int.Parse(nudOutLaptop.Text);
                    int result = valueOne - valuetwo;
                    this.txtQuantity.Text = result.ToString();

               */

                //  int reOne = this.nudLaptop.Value;
                this.nudOutDesktopPo.Value = this.nudDesktopPo.Value;
                this.nudOutPrinterPo.Value = this.nudPrinterPo.Value;
                this.nudOutPendrivePo.Value = this.nudPendrivePo.Value;
                this.dateTimePicker1Po.Value = this.dtpInsertdatePo.Value;

                this.txtPricePo.Text = (this.nudOutLaptopPo.Value * 40000 + this.nudOutDesktopPo.Value * 40000 + this.nudOutPrinterPo.Value * 5000 + this.nudOutPendrivePo.Value * 1000).ToString();

                this.txtPriceOP.Text = this.txtPricePo.Text;

            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

           

        }

        private void ClearAll()
        {
         //   this.csid.Clear();
            //this.txtId.ReadOnly = true;

              this.nudDiscount.Value=0;

              this.nudLaptopPo.Value = 0;
              this.nudOutLaptopPo.Value = 0;
              this.nudOutDesktopPo.Value = 0;
              this.nudDesktopPo.Value = 0;
              this.nudOutPrinterPo.Value = 0;
              this.nudPrinterPo.Value = 0;
              this.nudOutPendrivePo.Value = 0;
              this.nudPendrivePo.Value = 0;
              
             this.txtPriceOP.Clear();
             this.txtTotalPo.Clear();

             this.csid.Clear();
       //     this.nudDesktop = 0;
            this.txtPricePo.Clear();
        //      this.txtTotalPo.Clear();
             

            this.dtpInsertdatePo.Text = "";
        //    this.cmbCategory.SelectedIndex = -1;

          //  this.AutoGenerateSaleID();
        }

        private void btnConfirmPo_Click(object sender, EventArgs e)
        {


            this.txtPriceOP.Text = (this.nudOutLaptopPo.Value * 40000 + this.nudOutDesktopPo.Value * 40000 + this.nudOutPrinterPo.Value * 5000 + this.nudOutPendrivePo.Value * 1000).ToString();
            
            
            this.txtTotalPo.Text = ((this.nudOutLaptopPo.Value * 40000 + this.nudOutDesktopPo.Value * 40000 + this.nudOutPrinterPo.Value * 5000 + this.nudOutPendrivePo.Value * 1000) - (this.nudOutLaptopPo.Value * 40000 + this.nudOutDesktopPo.Value * 40000 + this.nudOutPrinterPo.Value * 5000 + this.nudOutPendrivePo.Value * 1000)*(this.nudDiscount.Value/100) ).ToString();

            

            
            try
            {


                this.Sql = "select * from ordersale where sid = '" + this.csid.Text + "'";

               
                    
                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count == 1)
                {


                    this.Sql = @"update ordersale
                        set laptop = '" + this.nudOutLaptopPo.Text + @"',
                        desktop = '" + this.nudOutDesktopPo.Text + @"',
                        printer = '" + this.nudOutPrinterPo.Text + @"',
                        pendrive = '" + this.nudOutPendrivePo.Text + @"',
                        price = '" + this.txtPriceOP.Text + @"',
                        orderDate = '" + this.dateTimePicker1Po.Text + @"',
                        total = '" + this.txtTotalPo.Text + @"',
                        discount = '" + this.nudDiscount.Text + @"'
                        where sid = '" + this.csid.Text + "';";
                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show(" Order Confirm, Sir ");
                    }
                    else
                    {
                        MessageBox.Show("Order Confirm failed");
                    }

                  

                }

               

            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

           
            this.ClearAll();
            this.AutoGenerateSaleID();


        }

        private void btnSearchPo_Click(object sender, EventArgs e)
        {
            string sql = "select * from ordersale where sid = '" + this.txtSearchPo.Text + "'";
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dvgSale.AutoGenerateColumns = false;
            this.dvgSale.DataSource = this.Ds.Tables[0];

        }









        


        

        
    }
}
