﻿namespace WinFormInventoryManagementSystem
{
    partial class ManagerDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerDashboard));
            this.mlogout = new System.Windows.Forms.Button();
            this.placeOrder = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtPriceMd = new System.Windows.Forms.TextBox();
            this.nudDiscountMd = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.dateTimePickerMd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.sidMd = new System.Windows.Forms.TextBox();
            this.txtTotalMd = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.nudOutPendriveMd = new System.Windows.Forms.NumericUpDown();
            this.nudOutPrinterMd = new System.Windows.Forms.NumericUpDown();
            this.nudOutDesktopMd = new System.Windows.Forms.NumericUpDown();
            this.nudOutLaptopMd = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnSaveMd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSearchMd = new System.Windows.Forms.TextBox();
            this.btnSearchMd = new System.Windows.Forms.Button();
            this.btnShowdetailSaleMd = new System.Windows.Forms.Button();
            this.dvgSaleMD = new System.Windows.Forms.DataGridView();
            this.sid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.laptop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.desktop = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pendrive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesmanId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnDeleteMd = new System.Windows.Forms.Button();
            this.btnAddEmployee = new System.Windows.Forms.Button();
            this.btnRefreshMd = new System.Windows.Forms.Button();
            this.lblManagerId = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.placeOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesmanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addSalesmanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesmanInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDiscountMd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutPendriveMd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutPrinterMd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutDesktopMd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutLaptopMd)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgSaleMD)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mlogout
            // 
            this.mlogout.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.mlogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mlogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mlogout.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mlogout.Location = new System.Drawing.Point(495, 90);
            this.mlogout.Name = "mlogout";
            this.mlogout.Size = new System.Drawing.Size(134, 43);
            this.mlogout.TabIndex = 0;
            this.mlogout.Text = "Logout";
            this.mlogout.UseVisualStyleBackColor = false;
            this.mlogout.Click += new System.EventHandler(this.mlogout_Click);
            // 
            // placeOrder
            // 
            this.placeOrder.BackColor = System.Drawing.SystemColors.GrayText;
            this.placeOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.placeOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.placeOrder.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.placeOrder.Location = new System.Drawing.Point(495, 159);
            this.placeOrder.Name = "placeOrder";
            this.placeOrder.Size = new System.Drawing.Size(134, 40);
            this.placeOrder.TabIndex = 41;
            this.placeOrder.Text = "Place order";
            this.placeOrder.UseVisualStyleBackColor = false;
            this.placeOrder.Click += new System.EventHandler(this.placeOrder_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.txtPriceMd);
            this.panel4.Controls.Add(this.nudDiscountMd);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.dateTimePickerMd);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.sidMd);
            this.panel4.Controls.Add(this.txtTotalMd);
            this.panel4.Controls.Add(this.lblTotal);
            this.panel4.Controls.Add(this.nudOutPendriveMd);
            this.panel4.Controls.Add(this.nudOutPrinterMd);
            this.panel4.Controls.Add(this.nudOutDesktopMd);
            this.panel4.Controls.Add(this.nudOutLaptopMd);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Location = new System.Drawing.Point(71, 63);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(300, 282);
            this.panel4.TabIndex = 43;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(46, 199);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 16);
            this.label13.TabIndex = 48;
            this.label13.Text = "Price";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 227);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(68, 16);
            this.label12.TabIndex = 48;
            this.label12.Text = "Discount";
            // 
            // txtPriceMd
            // 
            this.txtPriceMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPriceMd.Location = new System.Drawing.Point(112, 196);
            this.txtPriceMd.Name = "txtPriceMd";
            this.txtPriceMd.Size = new System.Drawing.Size(77, 22);
            this.txtPriceMd.TabIndex = 49;
            // 
            // nudDiscountMd
            // 
            this.nudDiscountMd.Location = new System.Drawing.Point(112, 226);
            this.nudDiscountMd.Name = "nudDiscountMd";
            this.nudDiscountMd.Size = new System.Drawing.Size(77, 20);
            this.nudDiscountMd.TabIndex = 47;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(8, 168);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 16);
            this.label10.TabIndex = 46;
            this.label10.Text = "Order date";
            // 
            // dateTimePickerMd
            // 
            this.dateTimePickerMd.CustomFormat = "yyyy-MM-dd";
            this.dateTimePickerMd.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePickerMd.Location = new System.Drawing.Point(112, 168);
            this.dateTimePickerMd.Name = "dateTimePickerMd";
            this.dateTimePickerMd.Size = new System.Drawing.Size(77, 20);
            this.dateTimePickerMd.TabIndex = 46;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 16);
            this.label8.TabIndex = 44;
            this.label8.Text = "Product ID";
            // 
            // sidMd
            // 
            this.sidMd.Enabled = false;
            this.sidMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sidMd.Location = new System.Drawing.Point(112, 3);
            this.sidMd.Name = "sidMd";
            this.sidMd.Size = new System.Drawing.Size(77, 22);
            this.sidMd.TabIndex = 44;
            // 
            // txtTotalMd
            // 
            this.txtTotalMd.Location = new System.Drawing.Point(112, 255);
            this.txtTotalMd.Name = "txtTotalMd";
            this.txtTotalMd.Size = new System.Drawing.Size(77, 20);
            this.txtTotalMd.TabIndex = 40;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(6, 255);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(88, 16);
            this.lblTotal.TabIndex = 39;
            this.lblTotal.Text = "Total Price ";
            // 
            // nudOutPendriveMd
            // 
            this.nudOutPendriveMd.Location = new System.Drawing.Point(112, 139);
            this.nudOutPendriveMd.Name = "nudOutPendriveMd";
            this.nudOutPendriveMd.Size = new System.Drawing.Size(77, 20);
            this.nudOutPendriveMd.TabIndex = 37;
            // 
            // nudOutPrinterMd
            // 
            this.nudOutPrinterMd.Location = new System.Drawing.Point(112, 107);
            this.nudOutPrinterMd.Name = "nudOutPrinterMd";
            this.nudOutPrinterMd.Size = new System.Drawing.Size(77, 20);
            this.nudOutPrinterMd.TabIndex = 36;
            // 
            // nudOutDesktopMd
            // 
            this.nudOutDesktopMd.Location = new System.Drawing.Point(112, 70);
            this.nudOutDesktopMd.Name = "nudOutDesktopMd";
            this.nudOutDesktopMd.Size = new System.Drawing.Size(77, 20);
            this.nudOutDesktopMd.TabIndex = 35;
            // 
            // nudOutLaptopMd
            // 
            this.nudOutLaptopMd.Location = new System.Drawing.Point(112, 33);
            this.nudOutLaptopMd.Name = "nudOutLaptopMd";
            this.nudOutLaptopMd.Size = new System.Drawing.Size(77, 20);
            this.nudOutLaptopMd.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(24, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 16);
            this.label5.TabIndex = 33;
            this.label5.Text = "Pendrive";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(37, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 32;
            this.label6.Text = "Printer";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(66, 16);
            this.label7.TabIndex = 31;
            this.label7.Text = "Desktop";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(34, 33);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 16);
            this.label15.TabIndex = 30;
            this.label15.Text = "Laptop";
            // 
            // btnSaveMd
            // 
            this.btnSaveMd.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSaveMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveMd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSaveMd.Location = new System.Drawing.Point(134, 352);
            this.btnSaveMd.Name = "btnSaveMd";
            this.btnSaveMd.Size = new System.Drawing.Size(75, 37);
            this.btnSaveMd.TabIndex = 38;
            this.btnSaveMd.Text = "Update ";
            this.btnSaveMd.UseVisualStyleBackColor = false;
            this.btnSaveMd.Click += new System.EventHandler(this.btnSaveMd_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtSearchMd);
            this.panel1.Controls.Add(this.btnSearchMd);
            this.panel1.Controls.Add(this.btnShowdetailSaleMd);
            this.panel1.Controls.Add(this.dvgSaleMD);
            this.panel1.Location = new System.Drawing.Point(14, 397);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(646, 174);
            this.panel1.TabIndex = 45;
            // 
            // txtSearchMd
            // 
            this.txtSearchMd.Location = new System.Drawing.Point(16, 5);
            this.txtSearchMd.Name = "txtSearchMd";
            this.txtSearchMd.Size = new System.Drawing.Size(152, 20);
            this.txtSearchMd.TabIndex = 48;
            // 
            // btnSearchMd
            // 
            this.btnSearchMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchMd.Location = new System.Drawing.Point(169, 2);
            this.btnSearchMd.Name = "btnSearchMd";
            this.btnSearchMd.Size = new System.Drawing.Size(76, 24);
            this.btnSearchMd.TabIndex = 47;
            this.btnSearchMd.Text = "Search";
            this.btnSearchMd.UseVisualStyleBackColor = true;
            this.btnSearchMd.Click += new System.EventHandler(this.btnSearchMd_Click);
            // 
            // btnShowdetailSaleMd
            // 
            this.btnShowdetailSaleMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowdetailSaleMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowdetailSaleMd.Location = new System.Drawing.Point(494, 3);
            this.btnShowdetailSaleMd.Name = "btnShowdetailSaleMd";
            this.btnShowdetailSaleMd.Size = new System.Drawing.Size(139, 22);
            this.btnShowdetailSaleMd.TabIndex = 4;
            this.btnShowdetailSaleMd.Text = "Show details ";
            this.btnShowdetailSaleMd.UseVisualStyleBackColor = true;
            this.btnShowdetailSaleMd.Click += new System.EventHandler(this.btnShowdetailSaleMd_Click);
            // 
            // dvgSaleMD
            // 
            this.dvgSaleMD.AllowUserToAddRows = false;
            this.dvgSaleMD.AllowUserToDeleteRows = false;
            this.dvgSaleMD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgSaleMD.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sid,
            this.laptop,
            this.desktop,
            this.printer,
            this.pendrive,
            this.orderDate,
            this.price,
            this.discount,
            this.total,
            this.salesmanId});
            this.dvgSaleMD.Location = new System.Drawing.Point(0, 26);
            this.dvgSaleMD.Name = "dvgSaleMD";
            this.dvgSaleMD.ReadOnly = true;
            this.dvgSaleMD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dvgSaleMD.Size = new System.Drawing.Size(641, 145);
            this.dvgSaleMD.TabIndex = 0;
            this.dvgSaleMD.DoubleClick += new System.EventHandler(this.dvgSaleMD_DoubleClick);
            // 
            // sid
            // 
            this.sid.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.sid.DataPropertyName = "sid";
            this.sid.HeaderText = "Sale ID";
            this.sid.Name = "sid";
            this.sid.ReadOnly = true;
            // 
            // laptop
            // 
            this.laptop.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.laptop.DataPropertyName = "laptop";
            this.laptop.HeaderText = "Laptop";
            this.laptop.Name = "laptop";
            this.laptop.ReadOnly = true;
            // 
            // desktop
            // 
            this.desktop.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.desktop.DataPropertyName = "desktop";
            this.desktop.HeaderText = "Desktop";
            this.desktop.Name = "desktop";
            this.desktop.ReadOnly = true;
            // 
            // printer
            // 
            this.printer.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.printer.DataPropertyName = "printer";
            this.printer.HeaderText = "Printer";
            this.printer.Name = "printer";
            this.printer.ReadOnly = true;
            // 
            // pendrive
            // 
            this.pendrive.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.pendrive.DataPropertyName = "pendrive";
            this.pendrive.HeaderText = "Pendrive";
            this.pendrive.Name = "pendrive";
            this.pendrive.ReadOnly = true;
            // 
            // orderDate
            // 
            this.orderDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.orderDate.DataPropertyName = "orderDate";
            this.orderDate.HeaderText = "OrderDate";
            this.orderDate.Name = "orderDate";
            this.orderDate.ReadOnly = true;
            // 
            // price
            // 
            this.price.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.price.DataPropertyName = "price";
            this.price.HeaderText = "Price";
            this.price.Name = "price";
            this.price.ReadOnly = true;
            // 
            // discount
            // 
            this.discount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.discount.DataPropertyName = "discount";
            this.discount.HeaderText = "Discount%";
            this.discount.Name = "discount";
            this.discount.ReadOnly = true;
            // 
            // total
            // 
            this.total.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.total.DataPropertyName = "total";
            this.total.HeaderText = "Total";
            this.total.Name = "total";
            this.total.ReadOnly = true;
            // 
            // salesmanId
            // 
            this.salesmanId.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.salesmanId.DataPropertyName = "salesmanId";
            this.salesmanId.HeaderText = "Salesman ID";
            this.salesmanId.Name = "salesmanId";
            this.salesmanId.ReadOnly = true;
            // 
            // btnDeleteMd
            // 
            this.btnDeleteMd.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnDeleteMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteMd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnDeleteMd.Location = new System.Drawing.Point(296, 351);
            this.btnDeleteMd.Name = "btnDeleteMd";
            this.btnDeleteMd.Size = new System.Drawing.Size(75, 37);
            this.btnDeleteMd.TabIndex = 46;
            this.btnDeleteMd.Text = "Delete ";
            this.btnDeleteMd.UseVisualStyleBackColor = false;
            this.btnDeleteMd.Click += new System.EventHandler(this.btnDeleteMd_Click);
            // 
            // btnAddEmployee
            // 
            this.btnAddEmployee.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnAddEmployee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEmployee.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnAddEmployee.Location = new System.Drawing.Point(495, 231);
            this.btnAddEmployee.Name = "btnAddEmployee";
            this.btnAddEmployee.Size = new System.Drawing.Size(134, 40);
            this.btnAddEmployee.TabIndex = 47;
            this.btnAddEmployee.Text = "Add Employee";
            this.btnAddEmployee.UseVisualStyleBackColor = false;
            this.btnAddEmployee.Click += new System.EventHandler(this.btnAddEmployee_Click);
            // 
            // btnRefreshMd
            // 
            this.btnRefreshMd.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnRefreshMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefreshMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefreshMd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefreshMd.Location = new System.Drawing.Point(215, 352);
            this.btnRefreshMd.Name = "btnRefreshMd";
            this.btnRefreshMd.Size = new System.Drawing.Size(75, 37);
            this.btnRefreshMd.TabIndex = 48;
            this.btnRefreshMd.Text = "Refresh ";
            this.btnRefreshMd.UseVisualStyleBackColor = false;
            this.btnRefreshMd.Click += new System.EventHandler(this.btnRefreshMd_Click);
            // 
            // lblManagerId
            // 
            this.lblManagerId.AutoSize = true;
            this.lblManagerId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManagerId.Location = new System.Drawing.Point(532, 20);
            this.lblManagerId.Name = "lblManagerId";
            this.lblManagerId.Size = new System.Drawing.Size(0, 16);
            this.lblManagerId.TabIndex = 50;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.placeOrderToolStripMenuItem,
            this.salesmanToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(672, 24);
            this.menuStrip1.TabIndex = 51;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // placeOrderToolStripMenuItem
            // 
            this.placeOrderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newOrderToolStripMenuItem});
            this.placeOrderToolStripMenuItem.Name = "placeOrderToolStripMenuItem";
            this.placeOrderToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.placeOrderToolStripMenuItem.Text = "Order";
            // 
            // salesmanToolStripMenuItem
            // 
            this.salesmanToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSalesmanToolStripMenuItem,
            this.salesmanInfoToolStripMenuItem});
            this.salesmanToolStripMenuItem.Name = "salesmanToolStripMenuItem";
            this.salesmanToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.salesmanToolStripMenuItem.Text = "Salesman";
            // 
            // addSalesmanToolStripMenuItem
            // 
            this.addSalesmanToolStripMenuItem.Name = "addSalesmanToolStripMenuItem";
            this.addSalesmanToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.addSalesmanToolStripMenuItem.Text = "Add Salesman";
            this.addSalesmanToolStripMenuItem.Click += new System.EventHandler(this.addSalesmanToolStripMenuItem_Click);
            // 
            // salesmanInfoToolStripMenuItem
            // 
            this.salesmanInfoToolStripMenuItem.Name = "salesmanInfoToolStripMenuItem";
            this.salesmanInfoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.salesmanInfoToolStripMenuItem.Text = "Salesman Info";
            this.salesmanInfoToolStripMenuItem.Click += new System.EventHandler(this.salesmanInfoToolStripMenuItem_Click);
            // 
            // newOrderToolStripMenuItem
            // 
            this.newOrderToolStripMenuItem.Name = "newOrderToolStripMenuItem";
            this.newOrderToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.newOrderToolStripMenuItem.Text = "New Order";
            this.newOrderToolStripMenuItem.Click += new System.EventHandler(this.newOrderToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // ManagerDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 583);
            this.Controls.Add(this.lblManagerId);
            this.Controls.Add(this.btnRefreshMd);
            this.Controls.Add(this.btnAddEmployee);
            this.Controls.Add(this.btnDeleteMd);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.placeOrder);
            this.Controls.Add(this.mlogout);
            this.Controls.Add(this.btnSaveMd);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "ManagerDashboard";
            this.Text = "ManagerDashboard";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ManagerDashboard_FormClosed);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDiscountMd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutPendriveMd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutPrinterMd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutDesktopMd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOutLaptopMd)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgSaleMD)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button mlogout;
        private System.Windows.Forms.Button placeOrder;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtPriceMd;
        private System.Windows.Forms.NumericUpDown nudDiscountMd;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateTimePickerMd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox sidMd;
        private System.Windows.Forms.TextBox txtTotalMd;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnSaveMd;
        private System.Windows.Forms.NumericUpDown nudOutPendriveMd;
        private System.Windows.Forms.NumericUpDown nudOutPrinterMd;
        private System.Windows.Forms.NumericUpDown nudOutDesktopMd;
        private System.Windows.Forms.NumericUpDown nudOutLaptopMd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnShowdetailSaleMd;
        private System.Windows.Forms.DataGridView dvgSaleMD;
        private System.Windows.Forms.Button btnDeleteMd;
        private System.Windows.Forms.TextBox txtSearchMd;
        private System.Windows.Forms.Button btnSearchMd;
        private System.Windows.Forms.Button btnAddEmployee;
        private System.Windows.Forms.Button btnRefreshMd;
        private System.Windows.Forms.Label lblManagerId;
        private System.Windows.Forms.DataGridViewTextBoxColumn sid;
        private System.Windows.Forms.DataGridViewTextBoxColumn laptop;
        private System.Windows.Forms.DataGridViewTextBoxColumn desktop;
        private System.Windows.Forms.DataGridViewTextBoxColumn printer;
        private System.Windows.Forms.DataGridViewTextBoxColumn pendrive;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn price;
        private System.Windows.Forms.DataGridViewTextBoxColumn discount;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesmanId;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem placeOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newOrderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesmanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSalesmanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesmanInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}