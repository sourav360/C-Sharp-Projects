﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormInventoryManagementSystem
{
    public partial class ImsDashboard : Form
    {

        private DataAccess Da { get; set; }

        private DataSet Ds { get; set; }

        private string Sql { get; set; }

        private Form1 Flogin{ get; set; }
        public ImsDashboard()
        {
            InitializeComponent();

           
            this.Da = new DataAccess();

          //  string sql = "select * from product;";
            this.PopulateGridView();
            this.GenerateProductID();
           

        }

      


        public ImsDashboard(string info,Form1 flogin)  
        {
            InitializeComponent();
          
            this.Flogin = flogin;

            this.Da = new DataAccess();
          
            this.PopulateGridView();
            this.GenerateProductID();
            this.lblSalesmanId.Text = info;


        }









        private void ImsDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();


        }

        private void logout_Click(object sender, EventArgs e)
        {
           // this.Close();//this.Visible = false;
            this.Hide();
            this.Flogin.Show();
        }

        private void btnShowdetails_Click(object sender, EventArgs e)
        {
            string sql = "select * from product;";

            this.PopulateGridView(sql);

        }

        private void PopulateGridView(string sql = "select * from product;")
        {
            this.Ds = this.Da.ExecuteQuery(sql);

            

            this.dvgProduct.AutoGenerateColumns = false;
            this.dvgProduct.DataSource = this.Ds.Tables[0];
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
            string sql = "select * from product where category = '" + this.txtSearch.Text + "';";
            this.PopulateGridView(sql);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

         try
            {

                
                this.Sql = "select * from product where pid = '" + this.txtId.Text + "'";
                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count == 1)
                {
           
            
            this.Sql = @"update product
                        set pname = '" + this.txtName.Text + @"',
                        version = '" + this.txtVersion.Text + @"',
                        quantity = '" + this.txtQuantity.Text + @"',
                        price = '" + this.txtPrice.Text + @"',
                        insertdate = '" + this.dtpInsertdate.Text + @"',
                        category = '" + this.cmbCategory.Text + @"'
                        where pid = '" + this.txtId.Text + "';";
            int count = this.Da.ExecuteUpdateQuery(this.Sql);
            if (count == 1)
            {
                MessageBox.Show("Data updated");
            }
            else
            {
                MessageBox.Show("Data update failed");
            }

           }

          





        else

        {
            this.Sql = @"insert into product
                    values ('" + this.txtId.Text + "', '" + this.txtName.Text + "','" + this.txtVersion.Text + "','" + this.txtQuantity.Text + "', '" + this.txtPrice.Text + "', '" + this.dtpInsertdate.Text + "', '" + this.cmbCategory.Text + "');";

            int count = this.Da.ExecuteUpdateQuery(this.Sql);
            if (count == 1)
            {
                MessageBox.Show("Data added in IMS ");
                
            }
            else
            {
                MessageBox.Show("Data insertion failed");
            }
        }

               this.PopulateGridView();
                this.ClearAll();
          }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during saving the data\n\n" + exc.Message);
            }
        }




        private void btnRefresh_Click(object sender, EventArgs e)
        {
            string sql = "select * from product;";

            this.PopulateGridView(sql);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
        
            try
            {
                string pid = this.dvgProduct.CurrentRow.Cells[0].Value.ToString();
           

                this.Sql = @"delete from product
                        where pid = '" + pid + "';";
                int count = this.Da.ExecuteUpdateQuery(this.Sql);
                if (count == 1)
                {
                    MessageBox.Show(pname + " has been deleted");
                }
                else
                {
                    MessageBox.Show("Data deletion failed");
                }

             
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }
        

        }

        private void dvgProduct_DoubleClick(object sender, EventArgs e)
        {
            try
            {

                this.txtId.Text = this.dvgProduct.CurrentRow.Cells["pid"].Value.ToString();
                this.txtName.Text = this.dvgProduct.CurrentRow.Cells["pname"].Value.ToString();
                this.txtVersion.Text = this.dvgProduct.CurrentRow.Cells["version"].Value.ToString();
                this.txtQuantity.Text = this.dvgProduct.CurrentRow.Cells["quantity"].Value.ToString();
                this.txtPrice.Text = this.dvgProduct.CurrentRow.Cells["price"].Value.ToString();
                this.dtpInsertdate.Text = this.dvgProduct.CurrentRow.Cells["insertdate"].Value.ToString();
                this.cmbCategory.Text = this.dvgProduct.CurrentRow.Cells["category"].Value.ToString();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {


            this.Sql = @"update product
                        set pname = '" + this.txtName.Text + @"',
                        version = '" + this.txtVersion.Text + @"',
                        quantity = '" + this.txtQuantity.Text + @"',
                        price = '" + this.txtPrice.Text + @"',
                        insertdate = '" + this.dtpInsertdate.Text + @"',
                        category = '" + this.cmbCategory.Text + @"'
                        where pid = '" + this.txtId.Text + "';";
            int count = this.Da.ExecuteUpdateQuery(this.Sql);
            if (count == 1)
            {
                MessageBox.Show("Data updated");
            }
            else
            {
                MessageBox.Show("Data update failed");
            }



            PopulateGridView();
            this.ClearAll();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }


        private void PopulateGridView()
        {

            string sql = "select * from product;";
            
            this.Ds = this.Da.ExecuteQuery(sql);



            this.dvgProduct.AutoGenerateColumns = false;
            this.dvgProduct.DataSource = this.Ds.Tables[0];
        }











        private void ClearAll()
        {
            try
            {

            this.txtId.Clear();
            //this.txtId.ReadOnly = true;
            this.txtName.Clear();
            this.txtVersion.Clear();
            this.txtQuantity.Clear();
            this.txtPrice.Clear();

            this.dtpInsertdate.Text = "";
            this.cmbCategory.SelectedIndex = -1;

            this.GenerateProductID();

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }
        }



        private void GenerateProductID()
        {
            try
            {

                this.Sql = "select * from product order by pid desc ";
                DataTable dt = this.Da.ExecuteQueryTable(this.Sql);
                string id = dt.Rows[0]["pid"].ToString();
                string[] str = id.Split('-');
                int number = Convert.ToInt32(str[1]);
                string autoId = "p-" + (++number).ToString("d3");

                this.txtId.Text = autoId;
            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }



        }



        /*

        private void btnAddtoCart_Click(object sender, EventArgs e)
        {

            try
            {


                this.nudOutLaptopMs.Value = this.nudLaptopMs.Value;

            /*    int valueOne = int.Parse(txtQuantity.Text);
                int valuetwo = int.Parse(nudOutLaptop.Text);
                int result = valueOne - valuetwo;
                this.txtQuantity.Text = result.ToString();

           

              //  int reOne = this.nudLaptop.Value;
                this.nudOutDesktopMs.Value = this.nudDesktopMs.Value;
                this.nudOutPrinterMs.Value = this.nudPrinterMs.Value;
                this.nudOutPendriveMs.Value = this.nudPendriveMs.Value;

                this.txtTotalMs.Text = (this.nudOutDesktopMs.Value * 40000 + this.nudOutLaptopMs.Value * 40000 + this.nudOutPrinterMs.Value * 5000 + this.nudOutPendriveMs.Value * 1000).ToString();

            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }

      */




        private PlaceOrder PlaceOrders { get; set; }

        private void placeOrder_Click(object sender, EventArgs e)
        {
            PlaceOrder sPlaceOrders = new PlaceOrder(this.lblSalesmanId.Text,this);
            
            sPlaceOrders.Show();
            this.Hide();

        }

       










    }
}
