﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormInventoryManagementSystem
{
    public partial class PlaceOrderMd : Form
    {

        private DataAccess Da { get; set; }

        private DataSet Ds { get; set; }

        private string Sql { get; set; }

        private ManagerDashboard AManagerDashboard { get; set; }
        public PlaceOrderMd()
        {
            InitializeComponent();
            this.Da = new DataAccess();
            AutoGenerateSaleID();
        }

        public PlaceOrderMd(string info, ManagerDashboard msDashboard)
        {
            InitializeComponent();
            this.Da = new DataAccess();
            this.AManagerDashboard = msDashboard;
            this.lblsalerID.Text = info;
            AutoGenerateSaleID();

        }

        private void PlaceOrderMd_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void PopulateGridViewSale()
        {
            string sql = "select * from ordersale;";
            this.Ds = this.Da.ExecuteQuery(sql);



            this.dvgSalePmd.AutoGenerateColumns = false;
            this.dvgSalePmd.DataSource = this.Ds.Tables[0];
        }

        private void btnShowdetailSalePMd_Click(object sender, EventArgs e)
        {
            PopulateGridViewSale();
        }

        private void btnSearchPMd_Click(object sender, EventArgs e)
        {

            string sql = "select * from ordersale where sid = '" + this.txtSearchPmd.Text + "'";
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dvgSalePmd.AutoGenerateColumns = false;
            this.dvgSalePmd.DataSource = this.Ds.Tables[0];

        }


        /*

        private void dvgSalePmd_DoubleClick(object sender, EventArgs e)
        {

            this.txtSidPMd.Text = this.dvgSalePmd.CurrentRow.Cells["sid"].Value.ToString();
            this.nudLaptopPMd.Text = this.dvgSalePmd.CurrentRow.Cells["laptop"].Value.ToString();
            this.nudDesktopPMd.Text = this.dvgSalePmd.CurrentRow.Cells["desktop"].Value.ToString();
            this.nudPrinterPMd.Text = this.dvgSalePmd.CurrentRow.Cells["printer"].Value.ToString();
            this.nudPendrivePMd.Text = this.dvgSalePmd.CurrentRow.Cells["pendrive"].Value.ToString();
            this.dateTimePickerPMd.Text = this.dvgSalePmd.CurrentRow.Cells["orderDate"].Value.ToString();
            this.txtPricePMd.Text = this.dvgSalePmd.CurrentRow.Cells["price"].Value.ToString();

            this.txtTotalPMd.Text = this.dvgSalePmd.CurrentRow.Cells["total"].Value.ToString();

        }

        */



        private void AutoGenerateSaleID()
        {
            try
            {

                this.Sql = "select * from ordersale order by sid desc ";
                DataTable dt = this.Da.ExecuteQueryTable(this.Sql);
                string id = dt.Rows[0]["sid"].ToString();
                string[] str = id.Split('-');
                int number = Convert.ToInt32(str[1]);
                string autoId = "s-" + (++number).ToString("d3");

                this.txtSidPMd.Text = autoId;
               // MessageBox.Show("An error has occured during deletion\n" + autoId);
            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }


        }

        private void btnAddtoCartPMd_Click(object sender, EventArgs e)
        {

            try
            {
                this.txtPricePMd.Text = (this.nudLaptopPMd.Value * 40000 + this.nudDesktopPMd.Value * 40000 + this.nudPrinterPMd.Value * 5000 + this.nudPendrivePMd.Value * 1000).ToString();



                this.Sql = "select * from ordersale where sid = '" + this.txtSidPMd.Text + "'";
                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count ==1 )
                {
                    MessageBox.Show("Product no info ");
                }


                
                    this.Sql = @"insert into ordersale
                    values ('" + this.txtSidPMd.Text + "', '" + this.nudLaptopPMd.Text + "','" + this.nudDesktopPMd.Text + "','" + this.nudPrinterPMd.Text + "', '" + this.nudPendrivePMd.Text + "',' " + this.txtPricePMd.Text + "', '" + this.dateTimePickerPMd.Text + "', '" + this.txtTotalPMd.Text + "', '" + this.lblsalerID.Text + "', '" + this.nudDiscountPMd.Text + "');";

                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Product Add to Cart in IMS ");
                        //  AutoGenerateSaleID();
                    }
                    else
                    {
                        MessageBox.Show("Data insertion Add to Cart failed");
                    }
                
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during saving the data\n\n" + exc.Message);
            }

            PopulateGridViewSale();
           // ClearAll();
        }

        private void ClearAll()
        {
              this.txtSidPMd.Clear();
            //  this.txtSidPMd.ReadOnly = true;

            //     this.nudLaptop.ToString.Clear();
                 this.nudLaptopPMd.Value = 0;
                 this.nudDesktopPMd.Value = 0;
                 this.nudPrinterPMd.Value = 0;
                 this.nudPendrivePMd.Value = 0;
                 this.nudDiscountPMd.Value = 0;
                 this.txtTotalPMd.Clear();
                 this.txtPricePMd.Clear();
        }

        private void btnConfirmPMd_Click(object sender, EventArgs e)
        {


            try
            {


                this.txtPricePMd.Text = (this.nudLaptopPMd.Value * 40000 + this.nudDesktopPMd.Value * 40000 + this.nudPrinterPMd.Value * 5000 + this.nudPendrivePMd.Value * 1000).ToString();


                this.txtTotalPMd.Text = ((this.nudLaptopPMd.Value * 40000 + this.nudDesktopPMd.Value * 40000 + this.nudPrinterPMd.Value * 5000 + this.nudPendrivePMd.Value * 1000) - (this.nudLaptopPMd.Value * 40000 + this.nudDesktopPMd.Value * 40000 + this.nudPrinterPMd.Value * 5000 + this.nudPendrivePMd.Value * 1000) * (this.nudDiscountPMd.Value / 100)).ToString();





                this.Sql = "select * from ordersale where sid = '" + this.txtSidPMd.Text + "'";



                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count == 1)
                {


                    this.Sql = @"update ordersale
                        set laptop = '" + this.nudLaptopPMd.Text + @"',
                        desktop = '" + this.nudDesktopPMd.Text + @"',
                        printer = '" + this.nudPrinterPMd.Text + @"',
                        pendrive = '" + this.nudPendrivePMd.Text + @"',
                        price = '" + this.txtPricePMd.Text + @"',
                        orderDate = '" + this.dateTimePickerPMd.Text + @"',
                        total = '" + this.txtTotalPMd.Text + @"',
                        discount = '" + this.nudDiscountPMd.Text + @"'
                        where sid = '" + this.txtSidPMd.Text + "';";
                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Your Order is Confirm, Sir");
                    }
                    else
                    {
                        MessageBox.Show("Your Order failed");
                    }



                }



            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

            PopulateGridViewSale();
            ClearAll();
            this.AutoGenerateSaleID();

        }

        private void btnToDashboardMd_Click(object sender, EventArgs e)
        {
            try
            {

            this.Hide();
            this.AManagerDashboard.Show();

            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }

        private void btnRefreshPoMd_Click(object sender, EventArgs e)
        {
            PopulateGridViewSale();
           
        }
























    }
}
