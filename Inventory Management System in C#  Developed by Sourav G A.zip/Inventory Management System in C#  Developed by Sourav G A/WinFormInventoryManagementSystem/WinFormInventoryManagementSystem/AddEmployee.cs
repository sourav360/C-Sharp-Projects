﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormInventoryManagementSystem
{
    public partial class AddEmployee : Form
    {


        private DataAccess Da { get; set; }

        private DataSet Ds { get; set; }

        private string Sql { get; set; }


        private ManagerDashboard AManagerDashboardEm { get; set; }

        public AddEmployee(ManagerDashboard amanagerDashboard)
            : this()
        {
            this.AManagerDashboardEm = amanagerDashboard;
        }


        public AddEmployee()
        {
            InitializeComponent();

            this.Da = new DataAccess();
            AutoGenerateProductID();
        }

        private void AddEmployee_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnToDashboardMd_Click(object sender, EventArgs e)
        {

            try
            {
                
                this.AManagerDashboardEm.Show();
                this.Hide();

            }


            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during \n" + exc.Message);
            }

        }


        private void PopulateGridView()
        {

            string sql = "select * from signin;";
            this.Ds = this.Da.ExecuteQuery(sql);



            this.dgvEmp.AutoGenerateColumns = false;
            this.dgvEmp.DataSource = this.Ds.Tables[0];
            
        }
        private void btnShowdetailSaleEm_Click(object sender, EventArgs e)
        {
            try
            {
                PopulateGridView();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during \n" + exc.Message);
            }

        }

        private void btnSearchEm_Click(object sender, EventArgs e)
        {
            string sql = "select * from signin where name = '" + this.txtSearchEm.Text + "'";
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dgvEmp.AutoGenerateColumns = false;
            this.dgvEmp.DataSource = this.Ds.Tables[0];
        }

        private void dgvEmp_DoubleClick(object sender, EventArgs e)
        {

            this.txtIdEm.Text = this.dgvEmp.CurrentRow.Cells["id"].Value.ToString();
            this.txtNameEm.Text = this.dgvEmp.CurrentRow.Cells["name"].Value.ToString();
            this.txtPassEm.Text = this.dgvEmp.CurrentRow.Cells["password"].Value.ToString();
            this.cmbTypeEm.Text = this.dgvEmp.CurrentRow.Cells["type"].Value.ToString();
            this.dtpJoindateEm.Text = this.dgvEmp.CurrentRow.Cells["joiningdate"].Value.ToString();
            this.txtSalaryEm.Text = this.dgvEmp.CurrentRow.Cells["salary"].Value.ToString();
           

        }




        private void btnSaveEm_Click(object sender, EventArgs e)
        {


            try
            {

                this.Sql = "select * from signin where id = '" + this.txtIdEm.Text + "'";
         //       this.Sql = "select * from signin where id = '" + this.txtIdEm.Text + "'";
                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count == 1)
                {


                    this.Sql = @"update signin
                        set name = '" + this.txtNameEm.Text + @"',
                        password = '" + this.txtPassEm.Text + @"',
                        type = '" + this.cmbTypeEm.Text + @"',
                        joiningdate = '" + this.dtpJoindateEm.Text + @"',
                        salary = '" + this.txtSalaryEm.Text + @"'     
                        where id = '" + this.txtIdEm.Text + "';";
                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Data updated");
                    }
                    else
                    {
                        MessageBox.Show("Data update failed");
                    }

                }

                else
                {
                    this.Sql = @"insert into signin
                    values ('" + this.txtIdEm.Text + "', '" + this.txtNameEm.Text+ "','" + this.txtPassEm.Text + "','" + this.cmbTypeEm.Text + "', '" + this.dtpJoindateEm.Text + "', '" + this.txtSalaryEm.Text + "');";

                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Data added in Signin Table ");
                        //this.GenerateProductID();
                    }
                    else
                    {
                        MessageBox.Show("Data insertion failed");
                    }
                }
                this.ClearAll();

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured \n\n" + exc.Message);
            }


        }


        private void ClearAll()
        {
            this.txtIdEm.Clear();
            this.txtNameEm.Clear();
            this.txtPassEm.Clear();      
            this.txtSalaryEm.Clear();
            this.dtpJoindateEm.Text = "";
            this.cmbTypeEm.SelectedIndex = -1;

            this.AutoGenerateProductID();
        }

        private void AutoGenerateProductID()
        {
            try
            {

                this.Sql = "select * from signin order by id desc ";
                DataTable dt = this.Da.ExecuteQueryTable(this.Sql);
                string id = dt.Rows[0]["id"].ToString();
                string[] str = id.Split('-');
                int number = Convert.ToInt32(str[1]);
                string autoId = "m-" + (++number).ToString("d3");

                this.txtIdEm.Text = autoId;
            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }



        }













        private void btnDeleteEm_Click(object sender, EventArgs e)
        {


            try
            {
                string sid = this.dgvEmp.CurrentRow.Cells[0].Value.ToString();
                

                this.Sql = @"delete from signin
                        where id = '" + sid + "';";
                int count = this.Da.ExecuteUpdateQuery(this.Sql);
                if (count == 1)
                {
                    MessageBox.Show(sid + " has been deleted");
                }
                else
                {
                    MessageBox.Show("Data deletion failed");
                }


            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

            PopulateGridView();



        }

        private void btnRefreshEm_Click(object sender, EventArgs e)
        {
            PopulateGridView();
        }

     

        private void btnShowSmid_Click(object sender, EventArgs e)
        {

            try
            {

                string sql = "select distinct signin.id,signin.name  from signin join ordersale on signin.id=ordersale.salesmanId;";
                this.Ds = this.Da.ExecuteQuery(sql);



                this.dvgSmid.AutoGenerateColumns = false;
                this.dvgSmid.DataSource = this.Ds.Tables[0];

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }


        }



     


















    }
}
