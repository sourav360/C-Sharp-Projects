﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormInventoryManagementSystem
{
    public partial class ManagerDashboard : Form
    {

        private DataAccess Da { get; set; }

        private DataSet Ds { get; set; }

        private string Sql { get; set; }

        private Form1 Flogin { get; set; }

        private PlaceOrder MPlaceOrder { get; set; }

        private PlaceOrderMd MdPlaceOrder { get; set; }

        public ManagerDashboard()
        {
            InitializeComponent();

            this.Da = new DataAccess();
        }

        public ManagerDashboard(string info,Form1 flogin)
            : this()
        {
            this.lblManagerId.Text = info;
            this.Flogin = flogin;
        }

        private void ManagerDashboard_FormClosed(object sender, FormClosedEventArgs e)
        {

            Application.Exit();
        }

        private void mlogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.Flogin.Show();
        }

        private void placeOrder_Click(object sender, EventArgs e)
        {
           
            
     //        PlaceOrder sPlaceOrders = new PlaceOrder(this.lblManagerId.Text,this);
     //
     //        this.MPlaceOrder = sPlaceOrders;
     //       
     //        this.Hide();
     //       this.MPlaceOrder.Show();


               PlaceOrderMd mdPlaceOrders = new PlaceOrderMd(this.lblManagerId.Text, this);

               this.MdPlaceOrder = mdPlaceOrders;
              
                this.Hide();
               this.MdPlaceOrder.Show();




        }


        private void PopulateGridViewSaleMd()
        {
            string sql = "select * from ordersale;";
            this.Ds = this.Da.ExecuteQuery(sql);



            this.dvgSaleMD.AutoGenerateColumns = false;
            this.dvgSaleMD.DataSource = this.Ds.Tables[0];
        }

        private void btnShowdetailSaleMd_Click(object sender, EventArgs e)
        {
            try
            {
                PopulateGridViewSaleMd();

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured \n\n" + exc.Message);
            }

        }

        private void btnSearchMd_Click(object sender, EventArgs e)
        {

            string sql = "select * from ordersale where sid = '" + this.txtSearchMd.Text + "'";
            this.Ds = this.Da.ExecuteQuery(sql);

            this.dvgSaleMD.AutoGenerateColumns = false;
            this.dvgSaleMD.DataSource = this.Ds.Tables[0];


        }

        private void dvgSaleMD_DoubleClick(object sender, EventArgs e)
        {

            this.sidMd.Text = this.dvgSaleMD.CurrentRow.Cells["sid"].Value.ToString();
            this.nudOutLaptopMd.Text = this.dvgSaleMD.CurrentRow.Cells["laptop"].Value.ToString();
            this.nudOutDesktopMd.Text = this.dvgSaleMD.CurrentRow.Cells["desktop"].Value.ToString();
            this.nudOutPrinterMd.Text = this.dvgSaleMD.CurrentRow.Cells["printer"].Value.ToString();
            this.nudOutPendriveMd.Text = this.dvgSaleMD.CurrentRow.Cells["pendrive"].Value.ToString();
            this.dateTimePickerMd.Text = this.dvgSaleMD.CurrentRow.Cells["orderDate"].Value.ToString();
            this.txtPriceMd.Text = this.dvgSaleMD.CurrentRow.Cells["price"].Value.ToString();
            this.nudDiscountMd.Text = this.dvgSaleMD.CurrentRow.Cells["discount"].Value.ToString();
            this.txtTotalMd.Text = this.dvgSaleMD.CurrentRow.Cells["total"].Value.ToString();

        }


        private void ClearAll()
        {
            try
            {

                this.sidMd.Clear();
                //this.txtId.ReadOnly = true;
                this.nudOutLaptopMd.Value = 0;

                this.nudOutDesktopMd.Value = 0;
                this.nudOutPrinterMd.Value = 0;
                this.nudOutPendriveMd.Value = 0;
                this.nudDiscountMd.Value = 0;
                

                this.txtPriceMd.Clear();
                this.txtTotalMd.Clear();

            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }
        }











        private void btnSaveMd_Click(object sender, EventArgs e)
        {

             try
            {
                this.txtPriceMd.Text = (this.nudOutLaptopMd.Value * 40000 + this.nudOutDesktopMd.Value * 40000 + this.nudOutPrinterMd.Value * 5000 + this.nudOutPendriveMd.Value * 1000).ToString();


                this.txtTotalMd.Text = ((this.nudOutLaptopMd.Value * 40000 + this.nudOutDesktopMd.Value * 40000 + this.nudOutPrinterMd.Value * 5000 + this.nudOutPendriveMd.Value * 1000) - (this.nudOutLaptopMd.Value * 40000 + this.nudOutDesktopMd.Value * 40000 + this.nudOutPrinterMd.Value * 5000 + this.nudOutPendriveMd.Value * 1000) * (this.nudDiscountMd.Value / 100)).ToString();




                this.Sql = "select * from ordersale where sid = '" + this.sidMd.Text + "'";
                this.Ds = this.Da.ExecuteQuery(this.Sql);
                if (this.Ds.Tables[0].Rows.Count == 1)
                {


                    this.Sql = @"update ordersale
                        set laptop = " + this.nudOutLaptopMd.Text + @",
                        desktop = " + this.nudOutDesktopMd.Text + @",
                        printer = " + this.nudOutPrinterMd.Text + @",
                        pendrive = " + this.nudOutPendriveMd.Text + @",
                        price = " + this.txtPriceMd.Text + @",
                        orderDate = '" + this.dateTimePickerMd.Text + @"',
                        total = '" + this.txtTotalMd.Text + @"',
                        discount=" + this.nudDiscountMd.Text + @"
                        where sid = '" + this.sidMd.Text + "';";
                    int count = this.Da.ExecuteUpdateQuery(this.Sql);
                    if (count == 1)
                    {
                        MessageBox.Show("Data updated");
                    }
                    else
                    {
                        MessageBox.Show("Data update failed");
                    }

                }

            }
             catch (Exception exc)
             {
                 MessageBox.Show("An error has occured \n\n" + exc.Message);
             }
             this.ClearAll();

        }

        private void btnDeleteMd_Click(object sender, EventArgs e)
        {

            try
            {
                string sid = this.dvgSaleMD.CurrentRow.Cells[0].Value.ToString();
             //   string name = this.dvgSaleMD.CurrentRow.Cells["pname"].Value.ToString();
                //MessageBox.Show(name);

                this.Sql = @"delete from ordersale
                        where sid = '" + sid + "';";
                int count = this.Da.ExecuteUpdateQuery(this.Sql);
                if (count == 1)
                {
                    MessageBox.Show(sid + " has been deleted");
                }
                else
                {
                    MessageBox.Show("Data deletion failed");
                }


            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

            this.ClearAll();
            PopulateGridViewSaleMd();

        }

        private void btnAddEmployee_Click(object sender, EventArgs e)
        {
          
             try
            { 

           AddEmployee addEmployee = new AddEmployee(this);
          
           addEmployee.Show();
           this.Hide();
           
                      
            }
             catch (Exception exc)
             {
                 MessageBox.Show("An error has occured during deletion\n" + exc.Message);
             }


        }











        private void btnRefreshMd_Click(object sender, EventArgs e)
        {
           
            PopulateGridViewSaleMd();
        }

        private void newOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {

            

            PlaceOrderMd mdPlaceOrders = new PlaceOrderMd(this.lblManagerId.Text, this);

            this.MdPlaceOrder = mdPlaceOrders;

            this.Hide();
            this.MdPlaceOrder.Show();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }

        private void addSalesmanToolStripMenuItem_Click(object sender, EventArgs e)
        {


            try
            {

                AddEmployee addEmployee = new AddEmployee(this);

                addEmployee.Show();
                this.Hide();


            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }


        }

        private void salesmanInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {


            try
            {

                AddEmployee addEmployee = new AddEmployee(this);

                addEmployee.Show();
                this.Hide();


            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

        










    }
}
