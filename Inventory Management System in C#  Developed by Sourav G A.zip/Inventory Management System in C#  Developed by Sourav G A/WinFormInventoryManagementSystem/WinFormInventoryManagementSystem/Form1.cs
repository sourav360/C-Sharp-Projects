﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinFormInventoryManagementSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
           


            try
            {



            string sql = "select *from signin where id='" + this.txtId.Text + "' and password='" + this.txtPass.Text + "' ;";

            DataAccess da = new DataAccess();
            DataSet ds = da.ExecuteQuery(sql);
            

            if (ds.Tables[0].Rows.Count == 1)                   // id and pass in one row 
            {
                MessageBox.Show("Login approved for " + ds.Tables[0].Rows[0][1].ToString() + "  As a " + ds.Tables[0].Rows[0][3].ToString());


                if (this.txtId.Text == "m-101")
               
                {
                    ManagerDashboard mDashboard = new ManagerDashboard(this.txtId.Text,this);

                    mDashboard.Show();
                    this.Hide();

                }
               else
               {
                    ImsDashboard imDashboard = new ImsDashboard(this.txtId.Text,this);

                    imDashboard.Show();
                    this.Hide();

                }


            }
            else
            {
                MessageBox.Show("Login Invalid");
            }


            }

            catch (Exception exc)
            {
                MessageBox.Show("An error has occured during deletion\n" + exc.Message);
            }




        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
