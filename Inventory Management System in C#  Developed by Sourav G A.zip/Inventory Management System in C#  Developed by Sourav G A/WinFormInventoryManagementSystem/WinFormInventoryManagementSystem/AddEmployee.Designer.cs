﻿namespace WinFormInventoryManagementSystem
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEmployee));
            this.btnToDashboardMd = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnDeleteEm = new System.Windows.Forms.Button();
            this.btnRefreshEm = new System.Windows.Forms.Button();
            this.btnSaveEm = new System.Windows.Forms.Button();
            this.cmbTypeEm = new System.Windows.Forms.ComboBox();
            this.dtpJoindateEm = new System.Windows.Forms.DateTimePicker();
            this.txtSalaryEm = new System.Windows.Forms.TextBox();
            this.txtPassEm = new System.Windows.Forms.TextBox();
            this.txtNameEm = new System.Windows.Forms.TextBox();
            this.txtIdEm = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSearchEm = new System.Windows.Forms.TextBox();
            this.btnSearchEm = new System.Windows.Forms.Button();
            this.btnShowdetailSaleEm = new System.Windows.Forms.Button();
            this.dgvEmp = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.password = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.joiningDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salary = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnShowSmid = new System.Windows.Forms.Button();
            this.dvgSmid = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmp)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvgSmid)).BeginInit();
            this.SuspendLayout();
            // 
            // btnToDashboardMd
            // 
            this.btnToDashboardMd.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnToDashboardMd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnToDashboardMd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnToDashboardMd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnToDashboardMd.Location = new System.Drawing.Point(482, 43);
            this.btnToDashboardMd.Name = "btnToDashboardMd";
            this.btnToDashboardMd.Size = new System.Drawing.Size(107, 40);
            this.btnToDashboardMd.TabIndex = 44;
            this.btnToDashboardMd.Text = "Dashboard";
            this.btnToDashboardMd.UseVisualStyleBackColor = false;
            this.btnToDashboardMd.Click += new System.EventHandler(this.btnToDashboardMd_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.btnDeleteEm);
            this.panel2.Controls.Add(this.btnRefreshEm);
            this.panel2.Controls.Add(this.btnSaveEm);
            this.panel2.Controls.Add(this.cmbTypeEm);
            this.panel2.Controls.Add(this.dtpJoindateEm);
            this.panel2.Controls.Add(this.txtSalaryEm);
            this.panel2.Controls.Add(this.txtPassEm);
            this.panel2.Controls.Add(this.txtNameEm);
            this.panel2.Controls.Add(this.txtIdEm);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Location = new System.Drawing.Point(19, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(363, 259);
            this.panel2.TabIndex = 45;
            // 
            // btnDeleteEm
            // 
            this.btnDeleteEm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteEm.Location = new System.Drawing.Point(248, 218);
            this.btnDeleteEm.Name = "btnDeleteEm";
            this.btnDeleteEm.Size = new System.Drawing.Size(71, 31);
            this.btnDeleteEm.TabIndex = 29;
            this.btnDeleteEm.Text = "Delete";
            this.btnDeleteEm.UseVisualStyleBackColor = true;
            this.btnDeleteEm.Click += new System.EventHandler(this.btnDeleteEm_Click);
            // 
            // btnRefreshEm
            // 
            this.btnRefreshEm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefreshEm.Location = new System.Drawing.Point(170, 218);
            this.btnRefreshEm.Name = "btnRefreshEm";
            this.btnRefreshEm.Size = new System.Drawing.Size(71, 31);
            this.btnRefreshEm.TabIndex = 28;
            this.btnRefreshEm.Text = "Refresh ";
            this.btnRefreshEm.UseVisualStyleBackColor = true;
            this.btnRefreshEm.Click += new System.EventHandler(this.btnRefreshEm_Click);
            // 
            // btnSaveEm
            // 
            this.btnSaveEm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveEm.Location = new System.Drawing.Point(93, 218);
            this.btnSaveEm.Name = "btnSaveEm";
            this.btnSaveEm.Size = new System.Drawing.Size(71, 31);
            this.btnSaveEm.TabIndex = 27;
            this.btnSaveEm.Text = "Save";
            this.btnSaveEm.UseVisualStyleBackColor = true;
            this.btnSaveEm.Click += new System.EventHandler(this.btnSaveEm_Click);
            // 
            // cmbTypeEm
            // 
            this.cmbTypeEm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTypeEm.FormattingEnabled = true;
            this.cmbTypeEm.Items.AddRange(new object[] {
            "Manager ",
            "Salesman "});
            this.cmbTypeEm.Location = new System.Drawing.Point(141, 95);
            this.cmbTypeEm.Name = "cmbTypeEm";
            this.cmbTypeEm.Size = new System.Drawing.Size(188, 21);
            this.cmbTypeEm.TabIndex = 26;
            // 
            // dtpJoindateEm
            // 
            this.dtpJoindateEm.CustomFormat = "yyyy-MM-dd";
            this.dtpJoindateEm.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpJoindateEm.Location = new System.Drawing.Point(141, 125);
            this.dtpJoindateEm.Name = "dtpJoindateEm";
            this.dtpJoindateEm.Size = new System.Drawing.Size(188, 20);
            this.dtpJoindateEm.TabIndex = 25;
            // 
            // txtSalaryEm
            // 
            this.txtSalaryEm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalaryEm.Location = new System.Drawing.Point(141, 162);
            this.txtSalaryEm.Name = "txtSalaryEm";
            this.txtSalaryEm.Size = new System.Drawing.Size(188, 22);
            this.txtSalaryEm.TabIndex = 22;
            // 
            // txtPassEm
            // 
            this.txtPassEm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassEm.Location = new System.Drawing.Point(141, 69);
            this.txtPassEm.Name = "txtPassEm";
            this.txtPassEm.Size = new System.Drawing.Size(188, 22);
            this.txtPassEm.TabIndex = 20;
            // 
            // txtNameEm
            // 
            this.txtNameEm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameEm.Location = new System.Drawing.Point(141, 41);
            this.txtNameEm.Name = "txtNameEm";
            this.txtNameEm.Size = new System.Drawing.Size(188, 22);
            this.txtNameEm.TabIndex = 19;
            // 
            // txtIdEm
            // 
            this.txtIdEm.Enabled = false;
            this.txtIdEm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdEm.Location = new System.Drawing.Point(141, 15);
            this.txtIdEm.Name = "txtIdEm";
            this.txtIdEm.Size = new System.Drawing.Size(188, 22);
            this.txtIdEm.TabIndex = 18;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(9, 18);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 16);
            this.label14.TabIndex = 11;
            this.label14.Text = "Salesman ID";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 125);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Insertdate";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(9, 97);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 16);
            this.label13.TabIndex = 12;
            this.label13.Text = "Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(9, 165);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 16);
            this.label10.TabIndex = 15;
            this.label10.Text = "Salary";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(8, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Password";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(9, 44);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 16);
            this.label11.TabIndex = 14;
            this.label11.Text = "Salesman  Name";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtSearchEm);
            this.panel1.Controls.Add(this.btnSearchEm);
            this.panel1.Controls.Add(this.btnShowdetailSaleEm);
            this.panel1.Controls.Add(this.dgvEmp);
            this.panel1.Location = new System.Drawing.Point(12, 293);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(593, 211);
            this.panel1.TabIndex = 46;
            // 
            // txtSearchEm
            // 
            this.txtSearchEm.Location = new System.Drawing.Point(7, 5);
            this.txtSearchEm.Name = "txtSearchEm";
            this.txtSearchEm.Size = new System.Drawing.Size(152, 20);
            this.txtSearchEm.TabIndex = 50;
            // 
            // btnSearchEm
            // 
            this.btnSearchEm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearchEm.Location = new System.Drawing.Point(160, 3);
            this.btnSearchEm.Name = "btnSearchEm";
            this.btnSearchEm.Size = new System.Drawing.Size(100, 24);
            this.btnSearchEm.TabIndex = 49;
            this.btnSearchEm.Text = "Search Name";
            this.btnSearchEm.UseVisualStyleBackColor = true;
            this.btnSearchEm.Click += new System.EventHandler(this.btnSearchEm_Click);
            // 
            // btnShowdetailSaleEm
            // 
            this.btnShowdetailSaleEm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowdetailSaleEm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowdetailSaleEm.Location = new System.Drawing.Point(450, 4);
            this.btnShowdetailSaleEm.Name = "btnShowdetailSaleEm";
            this.btnShowdetailSaleEm.Size = new System.Drawing.Size(139, 22);
            this.btnShowdetailSaleEm.TabIndex = 5;
            this.btnShowdetailSaleEm.Text = "Show details ";
            this.btnShowdetailSaleEm.UseVisualStyleBackColor = true;
            this.btnShowdetailSaleEm.Click += new System.EventHandler(this.btnShowdetailSaleEm_Click);
            // 
            // dgvEmp
            // 
            this.dgvEmp.AllowUserToAddRows = false;
            this.dgvEmp.AllowUserToDeleteRows = false;
            this.dgvEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmp.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.name,
            this.password,
            this.type,
            this.joiningDate,
            this.salary});
            this.dgvEmp.Location = new System.Drawing.Point(0, 32);
            this.dgvEmp.Name = "dgvEmp";
            this.dgvEmp.ReadOnly = true;
            this.dgvEmp.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmp.Size = new System.Drawing.Size(589, 176);
            this.dgvEmp.TabIndex = 0;
            this.dgvEmp.DoubleClick += new System.EventHandler(this.dgvEmp_DoubleClick);
            // 
            // id
            // 
            this.id.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.id.DataPropertyName = "id";
            this.id.HeaderText = "ID";
            this.id.Name = "id";
            this.id.ReadOnly = true;
            // 
            // name
            // 
            this.name.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.name.DataPropertyName = "name";
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            // 
            // password
            // 
            this.password.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.password.DataPropertyName = "password";
            this.password.HeaderText = "Password";
            this.password.Name = "password";
            this.password.ReadOnly = true;
            // 
            // type
            // 
            this.type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.type.DataPropertyName = "type";
            this.type.HeaderText = "Type";
            this.type.Name = "type";
            this.type.ReadOnly = true;
            // 
            // joiningDate
            // 
            this.joiningDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.joiningDate.DataPropertyName = "joiningDate";
            this.joiningDate.HeaderText = "Joining Date";
            this.joiningDate.Name = "joiningDate";
            this.joiningDate.ReadOnly = true;
            // 
            // salary
            // 
            this.salary.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.salary.DataPropertyName = "salary";
            this.salary.HeaderText = "Salary";
            this.salary.Name = "salary";
            this.salary.ReadOnly = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnShowSmid);
            this.panel4.Controls.Add(this.dvgSmid);
            this.panel4.Location = new System.Drawing.Point(425, 125);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(176, 165);
            this.panel4.TabIndex = 52;
            // 
            // btnShowSmid
            // 
            this.btnShowSmid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnShowSmid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShowSmid.Location = new System.Drawing.Point(57, 4);
            this.btnShowSmid.Name = "btnShowSmid";
            this.btnShowSmid.Size = new System.Drawing.Size(112, 22);
            this.btnShowSmid.TabIndex = 51;
            this.btnShowSmid.Text = "Show SMID";
            this.btnShowSmid.UseVisualStyleBackColor = true;
            this.btnShowSmid.Click += new System.EventHandler(this.btnShowSmid_Click);
            // 
            // dvgSmid
            // 
            this.dvgSmid.AllowUserToAddRows = false;
            this.dvgSmid.AllowUserToDeleteRows = false;
            this.dvgSmid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgSmid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Sname});
            this.dvgSmid.Location = new System.Drawing.Point(6, 32);
            this.dvgSmid.Name = "dvgSmid";
            this.dvgSmid.ReadOnly = true;
            this.dvgSmid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dvgSmid.Size = new System.Drawing.Size(163, 127);
            this.dvgSmid.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "id";
            this.dataGridViewTextBoxColumn1.HeaderText = "  ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // Sname
            // 
            this.Sname.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Sname.DataPropertyName = "name";
            this.Sname.HeaderText = "Name";
            this.Sname.Name = "Sname";
            this.Sname.ReadOnly = true;
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 516);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnToDashboardMd);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "AddEmployee";
            this.Text = "AddEmployee";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AddEmployee_FormClosed);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmp)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dvgSmid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnToDashboardMd;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnDeleteEm;
        private System.Windows.Forms.Button btnRefreshEm;
        private System.Windows.Forms.Button btnSaveEm;
        private System.Windows.Forms.ComboBox cmbTypeEm;
        private System.Windows.Forms.DateTimePicker dtpJoindateEm;
        private System.Windows.Forms.TextBox txtSalaryEm;
        private System.Windows.Forms.TextBox txtPassEm;
        private System.Windows.Forms.TextBox txtNameEm;
        private System.Windows.Forms.TextBox txtIdEm;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvEmp;
        private System.Windows.Forms.Button btnShowdetailSaleEm;
        private System.Windows.Forms.TextBox txtSearchEm;
        private System.Windows.Forms.Button btnSearchEm;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn password;
        private System.Windows.Forms.DataGridViewTextBoxColumn type;
        private System.Windows.Forms.DataGridViewTextBoxColumn joiningDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn salary;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnShowSmid;
        private System.Windows.Forms.DataGridView dvgSmid;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sname;
    }
}